Hello!

To run this program open it up in an IDE (any will do, but I used Visual Studio to run this. 

Open the SDLDungeonGame.sln and in the folder higharchy choose Source Files, then GameCore.cpp 

Congratulations! You can now run/play the game. It is a little Finiky, but it gets the job done. 