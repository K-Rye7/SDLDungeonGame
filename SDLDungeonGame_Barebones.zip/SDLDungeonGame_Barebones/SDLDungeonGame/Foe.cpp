#include "foe.h"

using namespace DungeonGame;


void Foe::InitializeMe(SDL_Renderer* pRenderer, FoeData* pFoeData)
{
	m_pFoeData = pFoeData;

	Initialize(Sprite::LoadTexture(pRenderer, "Assets/foe00.bmp"));
	m_Size = Vector2d(96.0f, 96.0f);
}

void Foe::Update(float deltaSeconds, WorldState& worldState, PlayerState& playerState)
{
	m_Position = m_pFoeData->position - m_Size * 0.5f;

	if (playerState.FoeCollidesWithPlayer(m_pFoeData))
	{
		worldState.m_CurrentDialogText = m_pFoeData->SomethingToSay;
	}
}