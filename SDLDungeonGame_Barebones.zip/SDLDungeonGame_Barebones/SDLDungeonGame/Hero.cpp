#include "hero.h"

using namespace DungeonGame;


void Hero::InitializeMe(SDL_Renderer* pRenderer)
{
	Initialize(Sprite::LoadTexture(pRenderer, "Assets/hero00.bmp"));
	m_Size = Vector2d(96.0f, 96.0f);
}

void Hero::Update(float deltaSeconds, WorldState& worldState, PlayerState& playerState)
{
	//Moving Logic
	{
		const float HERO_PIXELS_PER_SECCOND = 300.0f * deltaSeconds;

		Vector2d newPosition = playerState.m_CurrentPosition + playerState.m_DesiredDirection * HERO_PIXELS_PER_SECCOND;

		if (worldState.GetTileTypeAtPosition(newPosition) == '.')
		{
			playerState.m_CurrentPosition = newPosition;
		}

		m_Position = playerState.m_CurrentPosition - Vector2d(m_Size.X * 0.5f, m_Size.Y * 0.85f);
	}

	//Shooting logic
	{
		playerState.m_ShotCooldownSeconds -= deltaSeconds;
		if (playerState.m_ShotCooldownSeconds < 0.0f)
		{
			playerState.m_ShotCooldownSeconds = 0.0f;
		}

		if (playerState.m_bWantsToShoot)
		{
			TryToShoot(playerState);
		}
	}
	m_bVisible = playerState.m_bAlive;
}

void Hero::TryToShoot(PlayerState& playerState)
{
	//Vector2d directionRec = playerState.m_DesiredDirection;

	if (playerState.m_ShotCooldownSeconds == 0.0f)
	{
		for (unsigned int i = 0; i < playerState.m_Bullets.size(); i++)
		{
			BulletData& currBullet = playerState.m_Bullets[i];
			if (!currBullet.bAlive)
			{
				playerState.m_ShotCooldownSeconds = 0.4f;

				currBullet.bAlive = true;
				currBullet.secondsAlive = 0.0f;
				currBullet.position = playerState.m_CurrentPosition;

				//currBullet.direction = Vector2d(0.0f, 1.0f);

				if (currBullet.direction == Vector2d(0.0f, 0.0f) && playerState.m_LastDirection != Vector2d(0.0f, 0.0f));
				{
					currBullet.direction = playerState.m_LastDirection;
				}

				/*if (currBullet.direction == Vector2d(0.0f, 0.0f))
				{
					currBullet.direction = Vector2d(0.0f, 1.0f);
				}*/



				/*if (playerState.m_DesiredDirection != Vector2d(0.0f, 0.0f))
				{
					currBullet.direction = playerState.m_DesiredDirection;
				}*/

				break;
			}
		}
	}
}