#include "Bullet.h"

using namespace DungeonGame;

void Bullet::InitializeMe(SDL_Renderer* pRenderer, BulletData* pBulletData)
{
	m_pBulletData = pBulletData;


	std::string textureFilename = "Assets/bullet00.bmp";
	Initialize(Sprite::LoadTexture(pRenderer, textureFilename.c_str()));
	m_Size = Vector2d(32.0f, 32.0f);
}

void Bullet::Update(float deltaSeconds, WorldState& worldState, PlayerState& playerState)
{
	m_Position = m_pBulletData->position - m_Size * 0.5f;
	m_bVisible = m_pBulletData->bAlive;

	/*if (m_pBulletData->bAlive && playerState.BulletCollidesWithPlayer(m_pBulletData))
	{
	m_pBulletData->bAlive = false;

	playerState.m_Inventory.push_back(m_pBulletData->type);
	}*/

	//makes the Bullets move away from the player 

	/*Vector2d BulletToPlayer = m_pBulletData->position - playerState.m_CurrentPosition; //reversing this will make the Bullets move twards the player
	float distance = BulletToPlayer.GetLength();
	if (distance < 180.0f)
	{
	const float MOVEMENT_SPEED = 80.0f * deltaSeconds;
	BulletToPlayer.Normalize();
	m_pBulletData->position = m_pBulletData->position + BulletToPlayer * MOVEMENT_SPEED;
	}*/

	if (m_pBulletData->bAlive)
	{
		m_pBulletData->secondsAlive += deltaSeconds;
		if (m_pBulletData->secondsAlive >= 1.0f)
		{
			m_pBulletData->bAlive = false;
		}

		const float BULLET_SPEED = 600.0f * deltaSeconds;
		m_pBulletData->position = m_pBulletData->position + m_pBulletData->direction * BULLET_SPEED;

		if (worldState.BulletCollidesWithItem(m_pBulletData))
		{
			m_pBulletData->bAlive = false;
		}
	}



}