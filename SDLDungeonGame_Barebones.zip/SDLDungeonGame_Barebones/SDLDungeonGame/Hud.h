#pragma once
#include "Sprite.h"
#include "SDL_ttf.h"

namespace DungeonGame
{
	class HUD : public Sprite
	{
	public:
		void InitializeMe(SDL_Renderer* pRenderer);
		virtual void Render(SDL_Renderer *pRenderer, const WorldState& worldState, const PlayerState& playerState, const Vector2d& baseTransformation = Vector2d());
		virtual void Cleanup();

	private:
		//void RenderDialogbox(SDL_Renderer *pRenderer, const WorldState& worldState, const PlayerState& playerState);
		SDL_Texture* m_pLivesTexture;
		SDL_Texture* m_pHPTexture;

		//SDL_Texture* m_pBackgroundTexture

		SDL_Texture* m_pDialogBackgroundTexture;
		TTF_Font* m_pDialogFont;
	};


}