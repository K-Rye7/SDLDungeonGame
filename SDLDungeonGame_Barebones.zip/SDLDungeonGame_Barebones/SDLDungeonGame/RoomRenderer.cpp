#include "RoomRenderer.h"

using namespace DungeonGame;

void RoomRenderer::InitializeMe(SDL_Renderer* pRenderer)
{
	m_pFloorTexture = (Sprite::LoadTexture(pRenderer, "Assets/floor00.bmp"));
	m_pWallTexture = (Sprite::LoadTexture(pRenderer, "Assets/wall00.bmp"));
}

void RoomRenderer::Render(SDL_Renderer *pRenderer, const WorldState& worldState, const PlayerState& playerState, const Vector2d& baseTransformation)
{
	int columnsRendered = 0;
	int rowsRendered = 0;
	for (unsigned int i = 0; i < worldState.m_Tiles.size(); i++)
	{
		char tileType = worldState.m_Tiles[i];

		SDL_Texture* pCurrTexture = nullptr;
		switch (tileType)
		{
		case '#':
			pCurrTexture = m_pWallTexture;
			break;
		case '.':
			pCurrTexture = m_pFloorTexture;
			break;
		}

		if (pCurrTexture)
		{
			SDL_Rect destRect = { 96 * columnsRendered + baseTransformation.X , 96 * rowsRendered + baseTransformation.Y, 96, 96 };
			SDL_RenderCopy(pRenderer, pCurrTexture, nullptr, &destRect);
		}

		columnsRendered++;
		if (columnsRendered % worldState.m_TilesPerRow == 0)
		{
			rowsRendered++;
			columnsRendered = 0;
		}
	}



	/*if (m_pTexture && m_bVisible)
	{
	SDL_Rect destRect = { (int)(m_Position.X + baseTransformation.X), (int)(m_Position.Y + baseTransformation.Y), (int)m_Size.X, (int)m_Size.Y };
	SDL_RenderCopy(pRenderer, m_pTexture, nullptr, &destRect);
	}*/
}