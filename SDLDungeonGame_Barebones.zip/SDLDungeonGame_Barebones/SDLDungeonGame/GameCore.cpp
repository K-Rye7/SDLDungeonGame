#include "GameCore.h"
#include "Sprite.h"
#include "hero.h"
#include "foe.h"
#include "RoomRenderer.h"
#include "Item.h"
#include "Bullet.h"
#include "Hud.h"

namespace DungeonGame
{
	/*
	Sprite testSprite;
	Hero heroSprite;
	Foe foeSprite;*/

	std::vector<Sprite*> spriteList;
	Vector2d g_cameraPosition;
	const unsigned int BULLET_COUNT = 3;

	void ItemData::OnHitByBullet(BulletData* pBullet)
	{
		HP--;
		if (HP <= 0)
		{
			bAlive = false;
			isItded--;
		}
	}

	void PlayerState::Initialize()
	{
		for (unsigned int i = 0; i < BULLET_COUNT; i++)
		{
			BulletData bullet = {};
			bullet.bAlive = false;
			m_Bullets.push_back(bullet);
		}

		Reset();
	}

	void PlayerState::Reset()
	{
		m_HP = 3;
		m_bAlive = true;

		m_bWantsToShoot = false;
		m_bHasFinishedGame = false;

		m_CurrentPosition = Vector2d(500.0f, 200.0f);
		m_DesiredDirection = Vector2d(0.0f, 0.0f);
		m_LastDirection = Vector2d(0.0f, 0.0f);

		m_ShotCooldownSeconds = 0.0f;
	}

	bool PlayerState::ItemCollidesWithPlayer(ItemData* pItem)
	{
		Vector2d itemToPlayer = pItem->position - m_CurrentPosition;
		float distance = itemToPlayer.GetLength();

		return distance < 48.0f;
	}

	bool PlayerState::FoeCollidesWithPlayer(FoeData* pFoe)
	{
		Vector2d foeToPlayer = pFoe->position - m_CurrentPosition;
		float distance = foeToPlayer.GetLength();

		return distance < 48.0f;
	}

	void PlayerState::inflictDamageOnPlayer()
	{
		m_HP--;
		if (m_HP <= 0)
		{
			m_bAlive = false;

			
		}
	}

	void WorldState::Initialize()
	{
		//TODO: Implement a counter for the amount left, and a win condition for killing them all. 
		//		Also HUD stuff.

		m_Tiles =
			"  ######                     "
			" #......#        ##########  "
			" #......#       #..........# "
			" #......#       #...###....# "
			" #......#       #....#.....# "
			" #......#   ####.....##....# "
			" #......####......##......## "
			" #..............###........# "
			" #..............#######...## "
			"  ##############      #...#  "
			"                      #...#  "
			"   ####################...#  "
			"  #.......................#  "
			"  #.......................#  "
			"  #....####################  "
			"  #.......................#  "
			"  #....#..............##..#  "
			"  #...........#...........#  "
			"  #..........###..........#  "
			"  #...........#...........#  "
			"  #...##...............####  "
			"  #..............#........#  "
			"  #..............#........#  "
			"   #####################.##  "
			"                      #...#  "
			"                      #...#  "
			"                       ###   ";

		//previous tiles per row
		//m_TilesPerRow = 10;

		//current tile per row
		m_TilesPerRow = 29;

		//This Shit about to be sloppy as fuck
		{
			ItemData item1 = {};
			item1.isItded = 0;
			item1.HP = 3;
			item1.bAlive = true;
			item1.type = ITEM_Book;
			item1.position = item1.InitialPosition = Vector2d(3.0f * 96.0f, 6.0f * 96.0f);
			m_Items.push_back(item1);

			ItemData item2 = {};
			item2.HP = 2;
			item2.bAlive = true;
			item2.type = ITEM_Toombstone;
			item2.position = item2.InitialPosition = Vector2d(7.0f * 96.0f, 6.0f * 96.0f);
			m_Items.push_back(item2);

			ItemData item3 = {};
			item3.HP = 3;
			item3.bAlive = true;
			item3.type = ITEM_Book;
			item3.position = item3.InitialPosition = Vector2d(9.0f * 96.0f, 8.0f * 96.0f);
			m_Items.push_back(item3);

			ItemData item4 = {};
			item4.HP = 2;
			item4.bAlive = true;
			item4.type = ITEM_Toombstone;
			item4.position = item4.InitialPosition = Vector2d(13.0f * 96.0f, 7.0f * 96.0f);
			m_Items.push_back(item4);

			ItemData item5 = {};
			item5.HP = 2;
			item5.bAlive = true;
			item5.type = ITEM_Toombstone;
			item5.position = item5.InitialPosition = Vector2d(16.0f * 96.0f, 6.0f * 96.0f);
			m_Items.push_back(item5);

			ItemData item6 = {};
			item6.HP = 3;
			item6.bAlive = true;
			item6.type = ITEM_Book;
			item6.position = item6.InitialPosition = Vector2d(19.0f * 96.0f, 4.0f * 96.0f);
			m_Items.push_back(item6);

			ItemData item7 = {};
			item7.HP = 3;
			item7.bAlive = true;
			item7.type = ITEM_Book;
			item7.position = item7.InitialPosition = Vector2d(26.0f * 96.0f, 4.0f * 96.0f);
			m_Items.push_back(item7);

			ItemData item9 = {};
			item9.HP = 2;
			item9.bAlive = true;
			item9.type = ITEM_Toombstone;
			item9.position = item9.InitialPosition = Vector2d(25.0f * 96.0f, 7.0f * 96.0f);
			m_Items.push_back(item9);

			ItemData item10 = {};
			item10.HP = 2;
			item10.bAlive = true;
			item10.type = ITEM_Toombstone;
			item10.position = item10.InitialPosition = Vector2d(22.0f * 96.0f, 8.0f * 96.0f);
			m_Items.push_back(item10);

			ItemData item11 = {};
			item11.HP = 3;
			item11.bAlive = true;
			item11.type = ITEM_Book;
			item11.position = item11.InitialPosition = Vector2d(26.0f * 96.0f, 11.0f * 96.0f);
			m_Items.push_back(item11);

			ItemData item12 = {};
			item12.HP = 2;
			item12.bAlive = true;
			item12.type = ITEM_Toombstone;
			item12.position = item12.InitialPosition = Vector2d(22.0f * 96.0f, 13.0f * 96.0f);
			m_Items.push_back(item12);

			ItemData item13 = {};
			item13.HP = 3;
			item13.bAlive = true;
			item13.type = ITEM_Book;
			item13.position = item13.InitialPosition = Vector2d(15.0f * 96.0f, 14.0f * 96.0f);
			m_Items.push_back(item13);

			ItemData item14 = {};
			item14.HP = 3;
			item14.bAlive = true;
			item14.type = ITEM_Book;
			item14.position = item14.InitialPosition = Vector2d(8.0f * 96.0f, 13.0f * 96.0f);
			m_Items.push_back(item14);

			ItemData item15 = {};
			item15.HP = 3;
			item15.bAlive = true;
			item15.type = ITEM_Book;
			item15.position = item15.InitialPosition = Vector2d(5.0f * 96.0f, 15.0f * 96.0f);
			m_Items.push_back(item15);

			ItemData item16 = {};
			item16.HP = 3;
			item16.bAlive = true;
			item16.type = ITEM_Book;
			item16.position = item16.InitialPosition = Vector2d(8.0f * 96.0f, 18.0f * 96.0f);
			m_Items.push_back(item16);

			ItemData item17 = {};
			item17.HP = 3;
			item17.bAlive = true;
			item17.type = ITEM_Book;
			item17.position = item17.InitialPosition = Vector2d(14.0f * 96.0f, 18.0f * 96.0f);
			m_Items.push_back(item17);

			ItemData item18 = {};
			item18.HP = 2;
			item18.bAlive = true;
			item18.type = ITEM_Toombstone;
			item18.position = item18.InitialPosition = Vector2d(16.0f * 96.0f, 18.0f * 96.0f);
			m_Items.push_back(item18);

			ItemData item19 = {};
			item19.HP = 2;
			item19.bAlive = true;
			item19.type = ITEM_Toombstone;
			item19.position = item19.InitialPosition = Vector2d(14.0f * 96.0f, 20.0f * 96.0f);
			m_Items.push_back(item19);

			ItemData item20 = {};
			item20.HP = 2;
			item20.bAlive = true;
			item20.type = ITEM_Toombstone;
			item20.position = item20.InitialPosition = Vector2d(16.0f * 96.0f, 20.0f * 96.0f);
			m_Items.push_back(item20);

			ItemData item21 = {};
			item21.HP = 3;
			item21.bAlive = true;
			item21.type = ITEM_Book;
			item21.position = item21.InitialPosition = Vector2d(6.0f * 96.0f, 22.0f * 96.0f);
			m_Items.push_back(item21);

			ItemData item22 = {};
			item22.HP = 3;
			item22.bAlive = true;
			item22.type = ITEM_Book;
			item22.position = item22.InitialPosition = Vector2d(9.0f * 96.0f, 23.0f * 96.0f);
			m_Items.push_back(item22);

			ItemData item23 = {};
			item23.HP = 2;
			item23.bAlive = true;
			item23.type = ITEM_Toombstone;
			item23.position = item23.InitialPosition = Vector2d(25.0f * 96.0f, 17.0f * 96.0f);
			m_Items.push_back(item23);

			ItemData item24 = {};
			item24.HP = 3;
			item24.bAlive = true;
			item24.type = ITEM_Book;
			item24.position = item24.InitialPosition = Vector2d(21.0f * 96.0f, 23.0f * 96.0f);
			m_Items.push_back(item24);

			ItemData item25 = {};
			item25.HP = 3;
			item25.bAlive = true;
			item25.type = ITEM_Book;
			item25.position = item25.InitialPosition = Vector2d(25.0f * 96.0f, 26.0f * 96.0f);
			m_Items.push_back(item25);
		}

		FoeData foe1 = {};
		foe1.position = foe1.InitialPosition = Vector2d(4.0f * 96.0f, 2.0f * 96.0f);
		foe1.SomethingToSay = "Kill all the enemies to win.";
		m_Foes.push_back(foe1);

		FoeData foe2 = {};
		foe2.position = foe2.InitialPosition = Vector2d(6.0f * 96.0f, 2.0f * 96.0f);
		foe2.SomethingToSay = "Use the ARROW keys to move, and SPACE to shoot.";
		m_Foes.push_back(foe2);

		Reset();
	}

	void WorldState::Reset()
	{
		m_CurrentDialogText = "";

		m_PlayerLives = 3;

		m_NumbEnimies = 25;

		for (int i = 0; i < m_Items.size(); i++)
		{
			

			ItemData& currItem = m_Items[i];
			if (currItem.type == ITEM_Book)
			{
				currItem.HP = 3;
			}
			else
			{
				currItem.HP = 2;
			}
			currItem.position = currItem.InitialPosition;

			currItem.bAlive = true;
		}
		for (int i = 0; i < m_Foes.size(); i++) 
		{
			FoeData& currFoe = m_Foes[i];
			currFoe.position = currFoe.InitialPosition;
		}
	}

	char WorldState::GetTileTypeAtPosition(const Vector2d& inPosition) const
	{
		int col = inPosition.X / 96.0f;
		int row = inPosition.Y / 96.0f;

		int index = row * m_TilesPerRow + col;
		if (index >= 0 && index < m_Tiles.size())
		{
			return m_Tiles[index];
		}
		return ' ';
	}

	bool WorldState::BulletCollidesWithItem(BulletData* pBullet)
	{
		bool  bHasCollided = false;

		for (unsigned int i = 0; i < m_Items.size(); i++)
		{
			ItemData& currItem = m_Items[i];

			if (currItem.bAlive)
			{
				Vector2d bulletToItem = pBullet->position - currItem.position;
				float distance = bulletToItem.GetLength();

				if (distance < 48.0f)
				{
					currItem.OnHitByBullet(pBullet);
					bHasCollided = true;
					break;
				}
			}
		}
		return bHasCollided;
	}

	void InitializeGame(SDL_Renderer* pRenderer, WorldState& worldState, PlayerState& playerState)
	{
		worldState.Initialize();
		playerState.Initialize();

		g_cameraPosition = Vector2d();

		/*Sprite*pBob = nullptr;
		pBob = new Sprite;
		delete pBob;*/

		Sprite* pBG = new Sprite;
		pBG->Initialize(Sprite::LoadTexture(pRenderer, "Assets/background.bmp"));
		pBG->m_Size = Vector2d(WINDOW_WIDTH, WINDOW_HEIGHT);
		spriteList.push_back(pBG);

		RoomRenderer* pRoomRenderer = new RoomRenderer;
		pRoomRenderer->InitializeMe(pRenderer);
		spriteList.push_back(pRoomRenderer);

		for (unsigned int i = 0; i < worldState.m_Items.size(); i++)
		{
			Item* pItem = new Item;
			pItem->InitializeMe(pRenderer, &worldState.m_Items[i]);
			//pItem->m_Position = Vector2d(200.0f, 20.0f);
			spriteList.push_back(pItem);
		}

		for (unsigned int i = 0; i < playerState.m_Bullets.size(); i++)
		{
			Bullet* pBullet = new Bullet;
			pBullet->InitializeMe(pRenderer, &playerState.m_Bullets[i]);
			//pItem->m_Position = Vector2d(200.0f, 20.0f);
			spriteList.push_back(pBullet);
		}

		Hero* pHero = new Hero;
		pHero->InitializeMe(pRenderer);
		pHero->m_Position = Vector2d(120.0f, 16.0f);
		spriteList.push_back(pHero);

		for (unsigned int i = 0; i < worldState.m_Foes.size(); i++)
		{
			Foe* pFoe = new Foe;
			pFoe->InitializeMe(pRenderer, &worldState.m_Foes[i]);
			//pFoe->m_Position = Vector2d(300.0f, 120.0f);
			spriteList.push_back(pFoe);
		}

		HUD* pHUD = new HUD;
		pHUD->InitializeMe(pRenderer);
		spriteList.push_back(pHUD);

	}

	void GetInput(const WorldState& worldState, PlayerState& playerState)
	{
		SDL_Event e = {};
		while (SDL_PollEvent(&e) != 0)
		{
			if (e.type == SDL_QUIT)
			{
				playerState.m_bHasFinishedGame = true;
			}
			else if (e.type == SDL_KEYDOWN)
			{
				auto keyCode = e.key.keysym.sym;
				switch (keyCode)
				{
				case SDLK_ESCAPE:
					playerState.m_bHasFinishedGame = true;
					break;
				case SDLK_UP:
					playerState.m_DesiredDirection.Y = -1.0f;
					playerState.m_LastDirection = Vector2d(0.0f, 0.0f);
					playerState.m_LastDirection.Y = -1.0f;
					break;
				case SDLK_DOWN:
					playerState.m_DesiredDirection.Y = 1.0f;
					playerState.m_LastDirection = Vector2d(0.0f, 0.0f);
					playerState.m_LastDirection.Y = 1.0f;
					break;
				case SDLK_LEFT:
					playerState.m_DesiredDirection.X = -1.0f;
					playerState.m_LastDirection = Vector2d(0.0f, 0.0f);
					playerState.m_LastDirection.X = -1.0f;
					break;
				case SDLK_RIGHT:
					playerState.m_DesiredDirection.X = 1.0f;
					playerState.m_LastDirection = Vector2d(0.0f, 0.0f);
					playerState.m_LastDirection.X = 1.0f;
					break;
				case SDLK_SPACE:
					playerState.m_bWantsToShoot = true;
					break;
				}
			}
			else if (e.type == SDL_KEYUP)
			{
				auto keyCode = e.key.keysym.sym;
				switch (keyCode)
				{
				case SDLK_UP:
				case SDLK_DOWN:
					playerState.m_DesiredDirection.Y = 0.0f;
					break;
				case SDLK_LEFT:
				case SDLK_RIGHT:
					playerState.m_DesiredDirection.X = 0.0f;
					break;
				case SDLK_SPACE:
					playerState.m_bWantsToShoot = false;
					break;
				}
			}
		}
	}

	void UpdateGame(float deltaSeconds, WorldState& worldState, PlayerState& playerState)
	{
		worldState.m_CurrentDialogText = "";
		worldState.m_ECounter = "Enemies: ";
		worldState.m_EnemyCount = std::to_string(worldState.m_NumbEnimies);
		worldState.m_ECounter += worldState.m_EnemyCount;

		for (int i = 0; i < spriteList.size(); i++)
		{
			spriteList[i]->Update(deltaSeconds, worldState, playerState);
		}

		g_cameraPosition = Vector2d(WINDOW_WIDTH * 0.5f, WINDOW_HEIGHT * 0.5f) - playerState.m_CurrentPosition;

	}

	void RenderGame(SDL_Renderer* pRenderer, const WorldState& worldState, const PlayerState& playerState)
	{
		SDL_RenderClear(pRenderer);



		for (int i = 0; i < spriteList.size(); i++)
		{
			spriteList[i]->Render(pRenderer, worldState, playerState, g_cameraPosition);
		}

		SDL_RenderPresent(pRenderer);
	}

	void CleanupGame()
	{
		for (int i = 0; i < spriteList.size(); i++)
		{
			spriteList[i]->Cleanup();
			delete spriteList[i];
		}

		Sprite::ClearTextures();
	}
}