#include "Hud.h"
#include <string>

using namespace DungeonGame;

void HUD::InitializeMe(SDL_Renderer* pRenderer)
{
	m_pLivesTexture = (Sprite::LoadTexture(pRenderer, "Assets/hero00.bmp"));
	//m_pHPTexture = (Sprite::LoadTexture(pRenderer, "Assets/wall00.bmp"));

	m_pDialogBackgroundTexture = (Sprite::LoadTexture(pRenderer, "Assets/txtBG.bmp"));
	m_pDialogFont = TTF_OpenFont("Assets/SpaceMono-Bold.ttf", 36);
}

void HUD::Render(SDL_Renderer *pRenderer, const WorldState& worldState, const PlayerState& playerState, const Vector2d& baseTransformation)
{
	for (int i = 0; i < worldState.m_PlayerLives; i++)
	{
		SDL_Rect destRect = { 32+i*64 , 32, 64, 64 };
		SDL_RenderCopy(pRenderer, m_pLivesTexture, nullptr, &destRect);
	}
	
	/*for (int i = 0; i < playerState.m_HP; i++)
	{
		SDL_Rect destRect = { 32 + i * 48 , 128, 48, 48 };
		SDL_RenderCopy(pRenderer, m_pHPTexture, nullptr, &destRect);
	}*/
	{
		//std::string EnemyCounter = "Enemies Left: ";
		//std::string result;

		//result = std::to_string(worldState.m_NumbEnimies);
		//EnemyCounter += result;

		SDL_Color textColor = { 250,250,250,0 };
		SDL_Surface* textSurface = TTF_RenderText_Blended_Wrapped(m_pDialogFont, worldState.m_ECounter.c_str(), textColor, WINDOW_WIDTH);
		SDL_Texture* textTexture = SDL_CreateTextureFromSurface(pRenderer, textSurface);
		int textWidth = textSurface->w;
		int textHeight = textSurface->h;
		SDL_FreeSurface(textSurface);
		SDL_Rect textRect = { 32, 90, textWidth, textHeight };
		SDL_RenderCopy(pRenderer, textTexture, nullptr, &textRect);
		SDL_DestroyTexture(textTexture);
	}

	if (worldState.m_CurrentDialogText != "")
	{
		SDL_Rect destRect = { 300 , 32, 700, 150 };
		SDL_RenderCopy(pRenderer, m_pDialogBackgroundTexture, nullptr, &destRect);


		//std::string dialogText = "Kill all the enimies to win. Use the ARROW keys to move, and SPACE to shoot.";

		SDL_Color textColor = { 240,32,200,0 };
		SDL_Surface* textSurface = TTF_RenderText_Blended_Wrapped(m_pDialogFont, worldState.m_CurrentDialogText.c_str(), textColor, destRect.w - 32);
		SDL_Texture* textTexture = SDL_CreateTextureFromSurface(pRenderer, textSurface);
		int textWidth = textSurface->w;
		int textHeight = textSurface->h;
		SDL_FreeSurface(textSurface);
		SDL_Rect textRect = { destRect.x + 32, destRect.y + 8, textWidth, textHeight };
		SDL_RenderCopy(pRenderer, textTexture, nullptr, &textRect);
		SDL_DestroyTexture(textTexture);

	}

	if (worldState.m_NumbEnimies <= 0)
	{
		SDL_Rect destRect = { 300 , 32, 700, 700 };
		SDL_RenderCopy(pRenderer, m_pDialogBackgroundTexture, nullptr, &destRect);


		std::string WinConText = "You Win!\nPress ESC to quit.";

		SDL_Color textColor = { 32,240,100,0 };
		SDL_Surface* textSurface = TTF_RenderText_Blended_Wrapped(m_pDialogFont, WinConText.c_str(), textColor, destRect.w - 32);
		SDL_Texture* textTexture = SDL_CreateTextureFromSurface(pRenderer, textSurface);
		int textWidth = textSurface->w;
		int textHeight = textSurface->h;
		SDL_FreeSurface(textSurface);
		SDL_Rect textRect = { destRect.x + 32, destRect.y + 8, textWidth, textHeight };
		SDL_RenderCopy(pRenderer, textTexture, nullptr, &textRect);
		SDL_DestroyTexture(textTexture);
	}

	//RenderDialogBox(pRenderer, worldState, playerState);



	/*int columnsRendered = 0;
	int rowsRendered = 0;
	for (unsigned int i = 0; i < worldState.m_Tiles.size(); i++)
	{
		char tileType = worldState.m_Tiles[i];

		SDL_Texture* pCurrTexture = nullptr;
		switch (tileType)
		{
		case '#':
			pCurrTexture = m_pWallTexture;
			break;
		case '.':
			pCurrTexture = m_pFloorTexture;
			break;
		}

		if (pCurrTexture)
		{
			SDL_Rect destRect = { 96 * columnsRendered + baseTransformation.X , 96 * rowsRendered + baseTransformation.Y, 96, 96 };
			SDL_RenderCopy(pRenderer, pCurrTexture, nullptr, &destRect);
		}

		columnsRendered++;
		if (columnsRendered % worldState.m_TilesPerRow == 0)
		{
			rowsRendered++;
			columnsRendered = 0;
		}
	}*/



	/*if (m_pTexture && m_bVisible)
	{
	SDL_Rect destRect = { (int)(m_Position.X + baseTransformation.X), (int)(m_Position.Y + baseTransformation.Y), (int)m_Size.X, (int)m_Size.Y };
	SDL_RenderCopy(pRenderer, m_pTexture, nullptr, &destRect);
	}*/
}

/*void HUD::RenderDialogbox(SDL_Renderer *pRenderer, const WorldState& worldState, const PlayerState& playerState);
{
	{
		SDL_Rect destRect = { 320, 32, 600, 200 };
		SDL_RenderCopy(pRenderer, m_pDialogBackgroundTexture, nullptr, &destRect);
	}

	std::string dialogText = "Oh man not again...";

	SDL_Color textColor = {240,32,200,0};
	SDL_Surface* textSurface = TTF_RenderText_Blended_Wrapped(m_pDialogFont, dialogText.c_str(), textColor, destRect.w - 32);
	SDL_Texture* textTexture = SDL_CreateTextureFromSurface(pRenderer, textSurface);

	int textWidth = textSurface->w;
	int textHeight = textSurface->h;
	SDL_FreeSurface

	SDL_Rect textRect = { destRect.x + 32, destRect.y + 8, textWidth, textHeight};
	SDL_RenderCopy(pRenderer, textTexture, nullptr, &destRect);

	SDL_DestroyTexture(TextTexture);
}*/

void HUD::Cleanup()
{
	Sprite::Cleanup();

	TTF_CloseFont(m_pDialogFont);
}