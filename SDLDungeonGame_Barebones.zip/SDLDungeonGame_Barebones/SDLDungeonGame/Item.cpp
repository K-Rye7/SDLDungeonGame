#include "Item.h"

using namespace DungeonGame;

void Item::InitializeMe(SDL_Renderer* pRenderer, ItemData* pItemData)
{
	m_pItemData = pItemData;


	std::string textureFilename = "Assets/book00.bmp";
	switch (m_pItemData->type)
	{
	case ITEM_Book:
		textureFilename = "Assets/book00.bmp";
		break;
	case ITEM_Toombstone:
		textureFilename = "Assets/tomb00.bmp";
		break;
	}

	Initialize(Sprite::LoadTexture(pRenderer, textureFilename.c_str()));

	m_Size = Vector2d(96.0f, 96.0f);
}

void Item::Update(float deltaSeconds, WorldState& worldState, PlayerState& playerState)
{
	m_Position = m_pItemData->position - m_Size * 0.5f;
	m_bVisible = m_pItemData->bAlive;

	if (m_pItemData->bAlive && playerState.ItemCollidesWithPlayer(m_pItemData))
	{
		m_pItemData->bAlive = false;

		playerState.m_Inventory.push_back(m_pItemData->type);

		worldState.m_NumbEnimies--;

		// Makes Items do Damage on on the player
		playerState.inflictDamageOnPlayer();

		if (playerState.m_bAlive)
		{
			worldState.m_PlayerLives--;
			playerState.Reset();

			if (worldState.m_PlayerLives <= 0)
			{
				worldState.Reset();
			}
		}
	}
	if (!m_pItemData->bAlive)
	{
		worldState.m_NumbEnimies--;
	}

	//makes the items move away from the player 
	Vector2d itemToPlayer = playerState.m_CurrentPosition - m_pItemData->position; //reversing this will make the items move twards the player
	float distance = itemToPlayer.GetLength();
	if (distance < 250.0f)
	{
		const float MOVEMENT_SPEED = 100.0f * deltaSeconds;
		itemToPlayer.Normalize();
		m_pItemData->position = m_pItemData->position + itemToPlayer * MOVEMENT_SPEED;
	}

	else if (m_pItemData->position != m_pItemData->InitialPosition)
	{
		const float MOVEMENT_SPEED = 100.0f * deltaSeconds;
		itemToPlayer.Normalize();
		m_pItemData->position = m_pItemData->position + itemToPlayer * MOVEMENT_SPEED;
	}

}